<?php 
require 'db.php'; 
session_start(); 
 
if ($_SERVER['REQUEST_METHOD'] == 'POST') { 
    $login = $_POST['login']; 
    $password = $_POST['password']; 
 
    $stmt = $db->prepare("SELECT * FROM users WHERE login = ?"); 
    $stmt->execute([$login]); 
    $user = $stmt->fetch(PDO::FETCH_ASSOC); 

    // Проверяем пользовательля
    if ($user && password_verify($password, $user['password'])) { 
        $_SESSION['user_id'] = $user['id']; 
        $_SESSION['rules'] = $user['rules']; // Сохраняем правила в сессии
        header('Location: index.php'); 
        exit(); 
    } else { 
        echo "Неверный логин или пароль!"; 
    } 
} 
?> 
 
 <!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/bootstrap.css">
    <link rel="stylesheet" href="./css/style.css">
    <script src="./js/bootstrap.bundle.min.js"></script>

    <link href="./css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>SIBERIAN CUSTOMS</title>
</head>
<body>
    <header class="p-3 text-bg-dark">
        <div class="container">
            <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
                <H2>SIBERIAN CUSTOMS</H2>
                <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
                    <li><a href="./index.html" class="nav-link px-2 text-white">Главная</a></li>
                    <li><a href="./gallery.html" class="nav-link px-2 text-white">Галерея</a></li>
                    <li><a href="./artists.html" class="nav-link px-2 text-secondary">Художники</a></li>
                </ul>
                <div class="text-end">
                    <button type="button" class="btn btn-outline-light me-2">Войти</button>
                    <button type="button" class="btn btn-light">Зарегистрироваться</button>
                </div>
            </div>
        </div>
    </header>
    <div class="  container d-flex align-items-center justify-content-center">
        <div class="col-md-7 col-lg-8">
            <h4 class="mb-3">Вход</h4>
            <form  method="POST" class="needs-validation" novalidate="">
                <div class="row g-3">
                    
                    <div class="col-12">
                        <label for="login" class="form-label">Логин</label>
                        <div class="input-group has-validation">
                            <span class="input-group-text">@</span>
                            <input type="text" class="form-control" name="login" id="login" placeholder="Придумайте логин"
                                required="">
                        </div>
                    </div>
                   
                    <div class="col-12">
                        <label for="password" class="form-label">Пароль</label>
                        <input type="password" class="form-control" name="password" id="password" placeholder="Придумайте пароль"
                            required="">
                    </div>
                  
                    <hr class="my-4">
                    <button class="w-100 btn btn-dark btn-lg" type="submit">Войти</button>
            </form>
        </div>
    </div>
</body>

</html>