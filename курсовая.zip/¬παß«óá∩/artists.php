<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/bootstrap.css">
    <link rel="stylesheet" href="./css/style.css">
    <script src="./js/bootstrap.bundle.min.js"></script>

    <link href="./css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>SIBERIAN CUSTOMS</title>
</head>

<body>

    <header class="p-3 text-bg-dark">

            <div class="container">
                <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
                  
          <H2>SIBERIAN CUSTOMS</H2>

                <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
                    <li><a href="index.php" class="nav-link px-2 text-white">Главная</a></li>
                    <li><a href="gallery.php" class="nav-link px-2 text-white">Галерея</a></li>
                    <li><a href="artists.php" class="nav-link px-2 text-secondary">Художники</a></li>

</ul>

                <div class="text-end">
                    <button type="button" class="btn btn-outline-light me-2">Войти</button>
                    <button type="button" class="btn btn-light">Зарегистрироваться</button>
                </div>
            </div>
        </div>
    </header>
    <main>

        <section class="py-5 text-center container">
            <div class="row py-lg-5">
                <div class="col-lg-6 col-md-8 mx-auto">
                    <h1 class="fw-light">Художники</h1>
                    <p class="lead text-body-secondary">На этой странице вы можете увидеть профили всех художников, чьи работы располагаются на сайте.</p>
                    <p>
                        <a href="./index.html" class="btn btn-dark my-2">На главную</a>
                        <a href="./gallery.html" class="btn btn-secondary my-2">Галерея</a>
                    </p>
                </div>
            </div>
        </section>
        <div class="container">
            <div class="row mb-5 text-center">
                <div class="col-lg-4 ">
                 <img class="artist" src="https://lh4.googleusercontent.com/proxy/ZSJMQ02UyUIXfLF0oc7v2rZIAbqvkHAYuNBxUOPZsqd_OkDhzYFzWkOY2uCO51fNE4euo8y0r_lb_l6hujCSXkWJfTcWoVT3aTw" alt="">
                    
                  <h2 class="fw-normal">Боровский Давид Борисович</h2>
                  <p>советский и российский театральный художник, график.</p>
                  <p><a class="btn btn-outline-dark" href="#">Подробнее »</a></p>
                </div><!-- /.col-lg-4 -->
                <div class="col-lg-4 ">
                  <img class="artist" src="https://upload.wikimedia.org/wikipedia/commons/b/b0/%28V%C3%ADctor_Clavijo%29_Historias_de_Luz._El_granito_de_luz_del_actor_V%C3%ADctor_Clavijo.jpg" alt="">
                  <h2 class="fw-normal">Педро Клавихо</h2>
                  <p>внук художника и фотографа Эдмундо Клавихо, является наследником иберийской культуры.
                  </p>
                  <p><a class="btn btn-outline-dark" href="#">Подробнее »</a></p>
                </div><!-- /.col-lg-4 -->
                <div class="col-lg-4 ">
                  <img class="artist" src="https://mosmit.ru/photos/3_692.jpg" alt="">
                  <h2 class="fw-normal">	
                    Владислав Алексеевич Провоторов
                    </h2>
                  <p>Aсоветский и российский художник, один из представителей российского виженари арт. </p>
                  <p><a class="btn btn-outline-dark" href="#">Подробнее »</a></p>
                </div><!-- /.col-lg-4 -->
              </div><!-- /.row -->
    </main>
    <!-- FOOTER -->
    <footer class="container">
        <p class="float-end"><a class=" text-dark" href="#">Вернуться наверх</a></p>
        <p>© 2017–2024 SIBERIAN CUSTOMS, Inc. ·</p>
    </footer>
    </main>
</body>

</html>