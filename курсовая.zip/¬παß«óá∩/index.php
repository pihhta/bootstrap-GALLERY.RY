<?php
require 'db.php';
session_start();

$isLoggedIn = isset($_SESSION['user_id']);
$isAdmin = false;

// Проверка, является ли пользователь администратором
if ($isLoggedIn) {
    $userId = $_SESSION['user_id'];

    // Получение информации о пользователе из базы данных
    $query = "SELECT rules FROM users WHERE id = :userId LIMIT 1";
    $stmt = $db->prepare($query);
    $stmt->execute([':userId' => $userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Проверка роли пользователя
    if ($user && $user['rules'] == 1) {
        $isAdmin = true; // Пользователь - администратор
    }
} 

//  данных картин
$query = "SELECT id, name,  photo, xar, artist FROM paintings";
$params = [];

// Подготовленный запрос
$stmt = $db->prepare($query);
if (!empty($params)) {
    $stmt->execute($params);
} else {
    $stmt->execute();
}
$siberian_customs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="./css/bootstrap.css">
  <link rel="stylesheet" href="./css/style.css">
  <script src="./js/bootstrap.bundle.min.js"></script>

  <link href="./css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <title>SIBERIAN CUSTOMS</title>
</head>

<body>

  <header class="p-3 text-bg-dark">
    <div class="container">
      <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
        
<H2>SIBERIAN CUSTOMS</H2>
        <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
          <li><a href="index.php" class="nav-link px-2 text-secondary">Главная</a></li>
          <li><a href="gallery.php" class="nav-link px-2 text-white">Галерея</a></li>
          <li><a href="artists.php" class="nav-link px-2 text-white">Художники</a></li>

        </ul>

       

        <div class="text-end">
          <button type="button" class="btn btn-outline-light me-2">Войти</button>
          <button type="button" class="btn btn-light">Зарегистрироваться</button>
        </div>
      </div>
    </div>
  </header>
  <main>

    <div id="myCarousel" class="carousel mb-5 slide mb-6" data-bs-ride="carousel">
      <div class="carousel-indicators">
        <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="0" class="" aria-label="Slide 1"></button>
        <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="1" aria-label="Slide 2" class=""></button>
        <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="2" aria-label="Slide 3" class="active"
          aria-current="true"></button>
      </div>
      <div class="carousel-inner">
        <div class="carousel-item first">
          <svg class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg"
            aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false">
            <rect width="100%" height="100%" fill="var(--bs-secondary-color)"></rect>
          </svg>
          <div class="container">
            <div class="carousel-caption text-start">
              <h1>SIBERIAN CUSTOMS - место, где  искусство объединяет людей</h1>
              <p class="opacity-75">Регистрируйтесь в качествем нового пользователя и оставляйте комментарии</p>
              <p><a class="btn btn-lg btn-outline-light" href="#">Зарегистрироваться</a></p>
            </div>
          </div>
        </div>
        <div class="carousel-item second">
          <svg class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg"
            aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false">
            <rect width="100%" height="100%" fill="var(--bs-secondary-color)"></rect>
          </svg>
          <div class="container">
            <div class="carousel-caption">
              <h1>У нас вы можете найти любого художника, который когда-либо творил</h1>
              <p>А также оставить комментарий о его работах</p>
              <p><a class="btn btn-lg btn-outline-light" href="#">Перейти</a></p>
            </div>
          </div>
        </div>
        <div class="carousel-item third active">
          <svg class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg"
            aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false">
            <rect width="100%" height="100%" fill="var(--bs-secondary-color)"></rect>
          </svg>
          <div class="container">
            <div class="carousel-caption text-end">
              <h1>Мы постоянно добавляем новые произведения искусства в базу данных</h1>
              <p>Оцените их</p>
              <p><a class="btn btn-lg btn-outline-light" href="#">Перейти</a></p>
            </div>
          </div>
        </div>
      </div>
      <button class="carousel-control-prev" type="button" data-bs-target="#myCarousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#myCarousel" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
      </button>
    </div>



    <div class="container marketing">

      <div class="row mt-5 mb-5 text-center">
        <div class="col-lg-4 mt-5">
         <img class="artist" src="https://lh4.googleusercontent.com/proxy/ZSJMQ02UyUIXfLF0oc7v2rZIAbqvkHAYuNBxUOPZsqd_OkDhzYFzWkOY2uCO51fNE4euo8y0r_lb_l6hujCSXkWJfTcWoVT3aTw" alt="">
            
          <h2 class="fw-normal">Боровский Давид Борисович</h2>
          <p>советский и российский театральный художник, график.</p>
          <p><a class="btn btn-outline-dark" href="#">Подробнее »</a></p>
        </div><!-- /.col-lg-4 -->
        <div class="col-lg-4 mt-5">
          <img class="artist" src="https://upload.wikimedia.org/wikipedia/commons/b/b0/%28V%C3%ADctor_Clavijo%29_Historias_de_Luz._El_granito_de_luz_del_actor_V%C3%ADctor_Clavijo.jpg" alt="">
          <h2 class="fw-normal">Педро Клавихо</h2>
          <p>внук художника и фотографа Эдмундо Клавихо, является наследником иберийской культуры.
          </p>
          <p><a class="btn btn-outline-dark" href="#">Подробнее »</a></p>
        </div><!-- /.col-lg-4 -->
        <div class="col-lg-4 mt-5">
          <img class="artist" src="https://mosmit.ru/photos/3_692.jpg" alt="">
          <h2 class="fw-normal">	
            Владислав Алексеевич Провоторов
            </h2>
          <p>Aсоветский и российский художник, один из представителей российского виженари арт. </p>
          <p><a class="btn btn-outline-dark" href="#">Подробнее »</a></p>
        </div><!-- /.col-lg-4 -->
      </div><!-- /.row -->




      <hr class="featurette-divider">

      <div class="row featurette">
        <div class="col-md-7  align-self-center">
          <h2 class="featurette-heading fw-normal lh-1 ">EX №1 <span class="text-body-secondary">Педро Клавихо</span></h2>
          <p class="lead">Материал: Холст, тушь Размеры: 79x78 см Год: 2019 </p>
        </div>
        <div class="col-md-5">
          <img src="https://kupolgallery.ru/wp-content/uploads/2024/02/134_417_2023-01-19_19_56_41-1024x816.jpg"
            width="500" height="500" alt="">

          <title>Placeholder</title>
          <rect width="100%" height="100%" fill="var(--bs-secondary-bg)"></rect>
          </svg>
        </div>
      </div>

      <hr class="featurette-divider">

      <div class="row featurette">
        <div class="col-md-7 order-md-2 align-self-center text-end">
          <h2 class="featurette-heading fw-normal lh-1">EX №2 <span class="text-body-secondary">Педро Клавихо</span>
          </h2>
          <p class="lead">Материал: Бумага, тушь Размеры: 70х100 см Год: 2018
          </p>
        </div>
        <div class="col-md-5 order-md-1">
          <img src="https://kupolgallery.ru/wp-content/uploads/2024/02/133_1148-1024x816.jpg" width="500" height="500"
            alt="">
          <title>Placeholder</title>
          <rect width="100%" height="100%" fill="var(--bs-secondary-bg)"></rect>
          </svg>
        </div>
      </div>

      <hr class="featurette-divider">

      <div class="row featurette">
        <div class="col-md-7 align-self-center">
          <h2 class="featurette-heading fw-normal lh-1">EX №3 <span
              class="text-body-secondary">Педро Клавихо</span></h2>
          <p class="lead">Материал: Холст, тушь Размеры: 153x133 см Год: 2018</p>
        </div>
        <div class="col-md-5">
          <img src="https://kupolgallery.ru/wp-content/uploads/2024/02/143_1152-1024x816.jpg" width="500" height="500"
            alt="">
            <title>Placeholder</title>
            <rect width="100%" height="100%" fill="var(--bs-secondary-bg)"></rect>
          </svg>
        </div>
      </div>

      <hr class="featurette-divider">

      <!-- /END THE FEATURETTES -->

    </div><!-- /.container -->


    <!-- FOOTER -->
    <footer class="container">
      <p class="float-end"><a class=" text-dark" href="#">Вернуться наверх</a></p>
      <p>© 2017–2024 SIBERIAN CUSTOMS, Inc. ·</p>
    </footer>
  </main>
</body>

</html>