<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="./css/bootstrap.css">
  <link rel="stylesheet" href="./css/style.css">
  <script src="./js/bootstrap.bundle.min.js"></script>

  <link href="./css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <title>SIBERIAN CUSTOMS</title>
</head>

<body>

  <header class="p-3 text-bg-dark">
    <div class="container">
      <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
        
<H2>SIBERIAN CUSTOMS</H2>

        <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
          <li><a href="index.php" class="nav-link px-2 text-white">Главная</a></li>
          <li><a href="gallery.php" class="nav-link px-2 text-secondary">Галерея</a></li>
          <li><a href="artists.php" class="nav-link px-2 text-white">Художники</a></li>

        </ul>

        <div class="text-end">
          <button type="button" class="btn btn-outline-light me-2">Войти</button>
          <button type="button" class="btn btn-light">Зарегистрироваться</button>
        </div>
      </div>
    </div>
  </header>
  <main>

    <section class="py-5 text-center container">
      <div class="row py-lg-5">
        <div class="col-lg-6 col-md-8 mx-auto">
          <h1 class="fw-light">Галерея</h1>
          <p class="lead text-body-secondary">Здесь собраны все картины, размещенные на нашем сайте. Если вы уже
            зарегистрированный пользователь, то при переходе на страницу картины можете оставить свой отзыв и оценку.
          </p>
          <p>
            <a href="./index.html" class="btn btn-dark my-2">На главную</a>
            <a href="./artists.html" class="btn btn-secondary my-2">Художники</a>
          </p>
        </div>
      </div>
    </section>

    <div class="album py-5 bg-body-tertiary">
      <div class="container">

        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
          <div class="col">
            <div class="card shadow-sm">
              <img class="image" src="https://storage07.litfund.ru/images/lots/493s2/493s2-038-SP526-6-Y5316383.jpg" alt="">
              <div class="card-body">
                <p class="card-text">Боровский Давид Борисович (1926–2004) «Натюрморт с самоваром». 1940-е. Холст, масло, 83×103 см.</p>
                <div class="d-flex justify-content-between align-items-center">
                  <div class="btn-group">


                  </div>

                </div>
              </div>
            </div>
          </div>
          <div class="col">
            <div class="card shadow-sm">
              <img class="image" src="https://storage07.litfund.ru/images/lots/462/462-085-D7105-1-Y1264377_un883.jpg" alt="">
              <div class="card-body">
                <p class="card-text">Провоторов Владислав Алексеевич (род. 1947) «Без названия». Середина 1970-х. Оргалит, масло, 58,2×72 см.</p>
                <div class="d-flex justify-content-between align-items-center">
                  <div class="btn-group">


                  </div>

                </div>
              </div>
            </div>
          </div>
          <div class="col">
            <div class="card shadow-sm">
              <img class="image" src="https://kupolgallery.ru/wp-content/uploads/2024/02/134_417_2023-01-19_19_56_41-1024x816.jpg" alt="">
              <div class="card-body">
                <p class="card-text">Материал: Холст, тушь Размеры: 79x78 см Год: 2019</p>
                <div class="d-flex justify-content-between align-items-center">
                  <div class="btn-group">


                  </div>

                </div>
              </div>
            </div>
          </div>

          <div class="col">
            <div class="card shadow-sm">
              <img class="image" src="https://kupolgallery.ru/wp-content/uploads/2024/02/133_1148-1024x816.jpg" alt="">
              <div class="card-body">
                <p class="card-text">Материал: Бумага, тушь Размеры: 70х100 см Год: 2018</p>
                <div class="d-flex justify-content-between align-items-center">
                  <div class="btn-group">
  

                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col">
            <div class="card shadow-sm">
              <img class="image" src="https://kupolgallery.ru/wp-content/uploads/2024/02/143_1152-1024x816.jpg" alt="">
              <div class="card-body">
                <p class="card-text">Материал: Холст, тушь Размеры: 153x133 см Год: 2018</p>
                <div class="d-flex justify-content-between align-items-center">
                  <div class="btn-group">

                  </div>

                </div>
              </div>
            </div>
          </div>
          <div class="col">
            <div class="card shadow-sm">
              <img class="image" src="https://www.shishkin-gallery.ru/upload/items/item_9936_591bb61c.jpg" alt="">
              <div class="card-body">
                <p class="card-text">
                  ВЕСЕЛЫЙ ЧАБАН
                  
                  1963
                  Цветная литография
                  37 x 49.5 см
                  
                  1 июля 2019, «Финальная ликвидация склада»
                  </p>
                <div class="d-flex justify-content-between align-items-center">
                  <div class="btn-group">
  
                  </div>

                </div>
              </div>
            </div>
          </div>

          <div class="col">
            <div class="card shadow-sm">
              <img class="image" src="https://www.oph-art.ru/other/product/mid/auc7/166.webp" alt="">
              <div class="card-body">
                <p class="card-text">Автор: Боровский Давид Борисович

                  бумага, тушь, перо, акварель, 23.5х31 см, 1960-е</p>
                <div class="d-flex justify-content-between align-items-center">
                  <div class="btn-group">
                 
                  </div>

                </div>
              </div>
            </div>
          </div>
          <div class="col">
            <div class="card shadow-sm">
              <img class="image" src="https://storage06.litfund.ru/images/lots/402/402-205-D6426-1-Y5173834-1.jpg" alt="">
              <div class="card-body">
                <p class="card-text">Провоторов Владислав Алексеевич (род. 1947) «Четыре всадника Апокалипсиса». 2015. Металл, печать, лак, 50×50 см.</p>
                <div class="d-flex justify-content-between align-items-center">
                  <div class="btn-group">
    
                  </div>

                </div>
              </div>
            </div>
          </div>
          <div class="col">
            <div class="card shadow-sm">
              <img class="image" src="https://storage07.litfund.ru/images/lots/447/cache/447-111-D6955-1-YB185057_m_700x700.jpg" alt="">
              <div class="card-body">
                <p class="card-text">Провоторов Владислав Алексеевич (род. 1947) «Без названия». Середина 1970-х. Холст, масло, 74×101 см.</p>
                <div class="d-flex justify-content-between align-items-center">
                  <div class="btn-group">


                  </div>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

  </main>
  <!-- FOOTER -->
  <footer class="container">
    <p class="float-end"><a class=" text-dark" href="#">Вернуться наверх</a></p>
    <p>© 2017–2024 SIBERIAN CUSTOMS, Inc. ·</p>
  </footer>
  </main>
</body>

</html>